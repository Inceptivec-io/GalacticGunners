# CTO ACCEPTANCE REVIEW — APP4 RETURN

## Decision

`GALACTIC_GUNNERS_DEVTEAM_HANDOFF_OUT_003_APP4` is **NOT FOUNDER-ACCEPTED**.

The APP4 return corrected a number of requested assets and state surfaces, but the current runtime still contains material gameplay, collision, scene-lifecycle and cross-surface inconsistencies. Automated APP4 `PASS` is insufficient because its verifier does not exercise the failure mode observed during real play.

## Root gameplay defect

At entry HEAD, `assets/js/entities.js` sizes several Arcade Physics bodies from `displayWidth` / `displayHeight` after sprite scaling. Phaser Arcade `Body.setSize()` expects body dimensions in the object's local/unscaled frame space. Feeding display-scaled dimensions and then rendering a scaled sprite effectively shrinks the collision body again.

This affects at least:
- Player
- PlayerLaser
- Nuke
- EnemyLaser
- EnemyMotherShipLaser
- Comet

It explains a visible projectile crossing an enemy image without the collision callback firing.

A second contributor is timer-driven projectile translation (`laser.y +=/-=` every 30/128 ms), which advances objects in discrete jumps rather than giving the Arcade body a velocity integrated by the physics step. With the new visual geometry this permits tunnelling between collision checks.

## APP4 verifier gap

`tools/verify_app4_founder_review_browser.js` checks:
- visual dimensions;
- angles;
- frame counts;
- static body dimensions;
- one Level-1 enemy count;
- manually created objects.

It does **not** launch live player projectiles through live moving enemies and prove collision callbacks. Therefore it could not certify gameplay fidelity.

## Confirmed current-state observations

1. Exact Gold/Silver Founder production web font binaries are correctly present. Do not replace them again. The remaining problem is active-surface use and styling consistency.
2. Player/scout/destroyer/mothership atlas work exists, but `enemyCruiser` still uses a blanket `836x941` spritesheet declaration even though the artwork is not a true uniform two-cell sheet.
3. Player scale has grown from the historically successful `0.03` to `0.058` and is visually overlarge.
4. Current laser scales (`0.052`, `0.044`, `0.058`) are now substantially larger than desired.
5. APP4 restored the correct historical populations: Level 1 = 58, Level 2 = 87, Boss regular cruisers = 72. These counts must not be reduced again.
6. Result screens still have duplicate legacy key/timer control paths alongside new shared result controls.
7. Final `Victory` remains legacy: two victory panels, centre logo, green styling and forced five-second progression.
8. `Titles` remains legacy: v001 symbol, duplicate victory imagery, green styling, score reset and forced fifteen-second progression.
9. Pause still misuses gameplay comet art, changes Resume hover to the Pause icon, and hides rather than stops its scene.
10. Info and several UI surfaces still apply inherited green/red tinting over finished Founder-owned art.
11. The 2019 story/credits copy contains spelling/grammar defects and does not yet present the current commercial lineage while preserving historical provenance.
12. Level completion bonus semantics are inconsistent: Level 1/2 display a bonus without adding it; Boss adds it.

## Historical reference rule

The original runtime around commit `87923524833b737c7e3bf1764dde0b6ebf495e62` is a behavioural reference for movement, class separation, population and collision semantics. Do not blindly revert new assets or commercial work. Restore the reliable behavioural contract and adapt it correctly to the new Founder-authoritative art.
