# GALACTIC_GUNNERS_DEVTEAM_HANDOFF_IN_004

## GAMEPLAY FIDELITY AND CROSS-SURFACE RESTORATION

**Priority:** P1 — Founder-acceptance blocking  
**Entry HEAD:** `be5bb36235c8c9ccd81917a3e33b0fbd808581b8`  
**Branch:** `feature/GG-COM-001`  
**Merge authority:** Founder only  
**Merge:** PROHIBITED  
**Scope:** one bounded correction sprint; no unrelated feature work.

---

# 1. Execution rule

This is a prescriptive implementation handoff. Do not reinterpret symptoms and invent alternative scope. Implement the target behaviour below, verify it in real gameplay, update evidence/registers/currentness, push one final clean branch state and return.

All line ranges below refer to entry HEAD `be5bb362...`.

---

# 2. Restore collision fidelity first — stop visual-overlap misses

## 2.1 `assets/js/entities.js` — entry lines approximately 18–149

### Player — current block approximately lines 18–28

Current defect:
- scale `0.058` is too large;
- physics body is created from `displayWidth/displayHeight`.

Required implementation:
- set Player visual scale to exactly `0.040` via `Align.scaleToGameW(this, 0.040)`;
- body sizing must use **source/local frame dimensions**, not display dimensions;
- body must cover the meaningful central hull, not transparent thrust/glow;
- use `this.width` / `this.height` (or exact frame dimensions) for local-space body sizing;
- centre body on the hull with an explicit offset if required;
- verify body world bounds visually/debug-wise against the hull after scale.

Do not restore the old art. Restore the old reliable collision contract around the new image.

### PlayerLaser — current block approximately lines 31–39

Current APP4 scale = `0.052`.

Founder target = approximately 40% of APP4 size.

Set:
- visual scale exactly `0.021`;
- visual angle exactly `-90°`;
- do **not** use `displayWidth/displayHeight` for `body.setSize()`;
- because the supplied laser art is horizontally authored but rendered vertically, collision-body width/height must represent the **vertical world projectile core** after visual rotation;
- establish a narrow vertical body centred on the bright laser core, using source/local dimensions with width/height intentionally cross-mapped where necessary;
- collision body must not be a tiny fraction produced by double-scaling.

### Nuke — current block approximately lines 41–51

Keep current visual authority and no particle spray, but:
- replace display-dimension body sizing with local/source-frame sizing;
- projectile body must represent the visible nuclear projectile core;
- retain single projectile -> collision/offscreen -> destroy projectile -> create `nukeBurst` lifecycle;
- no Phaser particle manager/emitter is to return.

### AlienScout / Enemy / EnemyCruiser — approximately lines 104–129

Set visual targets:
- `AlienScout`: `0.025`
- standard `Enemy`: `0.024`
- `EnemyCruiser`: `0.034`

These are exact baseline targets for the 1366x665 Founder review surface. They may scale responsively through the existing width-relative mechanism, but do not alter these constants in this sprint without returning a blocker.

Each class must have a class-specific Arcade body representing its actual hull. Do not rely on full transparent atlas bounds, and do not use display dimensions in `setSize()`.

### EnemyLaser — approximately lines 131–140

Current APP4 scale = `0.044`.

Set:
- visual scale exactly `0.018`;
- angle exactly `+90°`;
- source/local-space, vertically oriented collision core;
- body aligned to visible projectile after rotation.

### EnemyMotherShipLaser — approximately lines 142–151

Current APP4 scale = `0.058`.

Set:
- visual scale exactly `0.023`;
- angle exactly `+90°`;
- local/source-space collision geometry;
- body aligned to visible projectile after rotation.

### Comet — approximately lines 170–181

Keep no-spin travel alignment.

Correct body sizing to local/source-frame geometry. Do not use display dimensions.

---

# 3. Move projectiles with Arcade Physics velocity, not timer teleportation

## 3.1 `assets/js/level1.js` — entry lines approximately 586–635
## 3.2 `assets/js/level2.js` — entry lines approximately 700–750
## 3.3 `assets/js/bosslevel.js` — entry lines approximately 892–965

Current defect:
- projectiles are manually advanced by changing `laser.y` in timer callbacks;
- a player projectile moves by 1% viewport height every 30 ms;
- enemy projectiles move by 1% viewport height every 128 ms;
- this can tunnel through narrow enemy bodies.

Required:

1. Give player/enemy/mothership projectile bodies Arcade velocities when the projectile is created.
2. Preserve the prior effective speed relationship, expressed responsively:
   - player laser velocity Y = `-(scene.game.config.height / 3)` pixels/sec;
   - enemy laser velocity Y = `+(scene.game.config.height * 0.078125)` pixels/sec;
   - mothership laser uses the same downward baseline unless existing game-design evidence requires a documented higher multiplier.
3. Convert each scene's `updateLasers()` timer to **culling/cleanup only**. It must no longer alter `laser.y`.
4. Projectile collisions remain Arcade `overlap()` registrations.
5. Do not replace the class-based collision model with generic pixel tests.

This is the principal gameplay-reliability correction.

---

# 4. Add deterministic collision assurance that reproduces real play

Create a new verifier:

`tools/verify_handoff_004_gameplay_and_surface.js`

Do not merely edit APP4 thresholds.

It must run against Docker runtime and prove at least:

### Player laser -> standard enemy
- instantiate/use real Level1 Enemy objects with their real body geometry;
- fire real PlayerLaser objects through them using physics velocity;
- minimum 100 deterministic intersecting trials;
- expected successful collision callback = 100/100;
- every successful intersecting shot destroys exactly one intended enemy and increments score/death state exactly once.

### Player laser -> Level2 enemy
- same test using Level2 runtime formation/classes;
- 100/100 deterministic intersections.

### Player laser -> Boss cruiser
- same using EnemyCruiser after cruiser-atlas correction;
- 100/100 deterministic intersections.

### Player laser -> mothership
- prove a visually intersecting shot decrements mothership health exactly once.

### Enemy laser -> player
- 100 deterministic intersections with current Player body;
- 100/100 expected hit callbacks, with one life event per projectile.

### Nuke lifecycle
- one projectile only;
- projectile removed on impact;
- one `nukeBurst` created;
- no projectile duplicate;
- zero particle emitter managers;
- affected target counts/scores are not double-applied.

The verifier must fail if any visually/geometrically intersecting test projectile crosses the target without callback.

---

# 5. Correct remaining sprite extraction — enemy cruiser

## `assets/js/preloader.js` — entry lines approximately 20–31 and 75–110

Current defect:

`enemyCruiser` still uses:

`load.spritesheet(... frameWidth: 836, frameHeight: 941)`

The supplied `gg_enemy_cruiser_v002_sheet.png` is not a legitimate uniform two-frame 836px sheet. It contains multiple non-uniform visual states.

Required:

1. Create `assets/images/owned/sprites/gg_enemy_cruiser_v002_atlas.json`.
2. Determine frame rectangles from actual transparent/white-space separation of the Founder source, not blanket division.
3. The sheet is 1672x941 and visibly comprises three intended cruiser states. Validate all three manually against the Founder image.
4. Load it via `this.load.atlas("enemyCruiser", ...)`.
5. Generate the `enemyCruiser` animation from explicit named frames only.
6. No neighbouring-frame content, duplicate ship, or clipped glow/thrust may appear.

### Logical-frame normalization

Player/scout/cruiser/destroyer animations use frames with different cropped heights/widths. Ensure animation does not cause the visible hull to grow/shrink or jump merely because frame source bounds differ.

Use a common logical source canvas/anchor per asset family (Phaser atlas `trimmed` metadata with common `sourceSize` / appropriate `spriteSourceSize`, or an equivalent deterministic approach). The hull reference point must remain fixed while thrust/effect extent changes.

For this sprint:
- Player remains visually stable on canonical frame 0 unless a multi-frame animation is proven hull-stable.
- Scout may animate only if hull centroid/nose stays fixed through the full sequence.
- Cruiser may animate only if its hull size/anchor remains fixed through frames.

---

# 6. Restore intended enemy populations — resize/reflow only

Do not reduce counts.

Authoritative counts from original behaviour and APP4 restoration:
- Level 1: **58 standard enemies** (`29 x 2`)
- Level 2: **87 standard enemies** (`29 x 3`)
- Boss regular cruiser formation: **72 cruisers** (`24 x 3`) plus mothership/scouts as existing game logic creates them.

## Level1 `createEnemies()` — entry approximately lines 400–425

Keep 29 x 2.

Change formation horizontal bounds to:
- min X = 6% viewport width;
- max X = 94% viewport width.

Rows must be positioned using actual rendered ship height + a clear minimum vertical gap rather than allowing art to overlap. Keep formation above shields/HUD.

## Level2 `createEnemies()` — approximately lines 410–440

Keep 29 x 3.

Use 6%–94% horizontal viewport span and actual-render-height-aware row spacing.

## Boss `createEnemies()` — approximately lines 500–535

Keep 24 x 3.

Use 5%–95% horizontal viewport span and actual-render-height-aware row spacing. Maintain a clear visual band between mothership, cruisers and shields/player.

At 1366x665:
- no neighbouring hulls overlap;
- no ship is clipped by screen edge;
- no formation touches HUD;
- full counts remain present.

---

# 7. Remove duplicate result-state input systems

## Level1 — `win()`, `updateContinue()`, `gameOver()`, `updateRestart()` around entry lines ~780–930
## Level2 — corresponding blocks around ~820–980
## Boss — corresponding result/restart blocks around ~1030–1210

Current architecture has shared `ggRenderVictory()` / `ggRenderGameOver()` controls plus legacy timer functions watching the same keys.

Required:

1. Shared result-control handling becomes the sole result input authority.
2. Remove `updateContinue()` and `updateRestart()` invocation from active scene setup where they duplicate shared result controls.
3. Remove/deprecate the duplicate active timer logic itself if no other state uses it.
4. One user action must produce one transition only.
5. Mouse/touch/controller/keyboard remain supported through one common result action map.

---

# 8. Make completion bonus semantics consistent and idempotent

## `assets/js/gg_runtime.js` — `ggPendingCompletionBonus()` around entry lines ~185–190
## Level1/Level2/Boss `win()` implementations

Current inconsistency:
- Level1/Level2 display a completion BONUS but do not add it to score.
- Boss adds the bonus before displaying final score.

Required rule:

1. Completion bonus = current existing formula unless Founder later changes scoring:
   `(currentLives + currentNukes + LevelRestart) * 100`.
2. Apply it **exactly once** when a level is completed.
3. Displayed SCORE on the result panel is the post-bonus score.
4. Displayed BONUS is the amount just applied.
5. Add a scene/run idempotency guard so repeated render/input callbacks cannot award the same bonus twice.
6. Verify Level1, Level2 and Boss with deterministic test state.

---

# 9. Resolve the duplicate/dead final-victory architecture

## `assets/js/bosslevel.js` — final `win()` around entry ~1080–1130
## `assets/js/victory.js` — entire file entry lines 1–~90

Current state:
- Boss renders a final mission-cleared result in-place.
- Separate `Victory` scene remains legacy and is effectively a second conflicting end-state implementation.

Required architecture:

1. Boss completion applies final bonus once, freezes final score/state, then starts `Victory`.
2. `Victory` is the **single final completion surface**.
3. Replace the entire current legacy `Victory` implementation.
4. Use exactly one Founder-approved no-values victory/mission-cleared panel.
5. Do not display duplicate panels.
6. Do not place `gg_logo_compact_v002.png` over the panel centre.
7. Use dynamic:
   - final SCORE;
   - WAVE = `FINAL`;
   - final BONUS.
8. Final visible controls:
   - `NEXT` -> `Titles` / Credits;
   - `REPLAY` -> governed BossLevel replay;
   - `MENU` -> governed main-menu reset.
9. No forced five-second transition.
10. All three visible controls work by mouse/touch; keyboard/controller equivalents also work.

---

# 10. Rebuild Titles as a current commercial Credits / Provenance surface

## `assets/js/titles.js` — entire entry file
## `assets/js/game.js` — `TitlesText` around entry lines ~125–140

Required:

1. Remove active use of superseded `gg_symbol_v001.png` where a current owned branding asset is available.
2. Remove duplicate victory-panel decorations.
3. Use current Gold/Silver production typography and current visual system.
4. Do not blanket-tint finished Founder artwork green/red.
5. Preserve truthful historical provenance:
   - original game created by Michael Leese in 2019 as an educational project;
   - Phaser 3 acknowledgement and applicable provenance/licence credits retained.
6. Add current commercial lineage without inventing unsupported names:
   - `Commercial continuation: Inceptivec Gamification`;
   - direct users to governed repository/credits/provenance documentation for complete contributor acknowledgements.
7. Do not reset `score` on scene entry.
8. Remove forced 15-second return to menu.
9. Provide an explicit working `MENU` control and a suitable `PLAY AGAIN`/`REPLAY` action using current UI standards.

---

# 11. Correct Pause semantics and lifecycle

## `assets/js/paused.js` — entry lines ~7–13, ~25–115, ~120–126

Required:

1. Remove the giant animated comet from the Pause scene. Comet art is gameplay-object art, not pause decoration.
2. `resumeHover` must not use the Pause icon. Resume must remain semantically Resume.
3. Do not tint current finished UI art arbitrary green/red. Use source art and approved subtle hover/pressed treatment.
4. Align PAUSED heading/subheading with Gold/Silver/cyan/orange language rather than legacy green.
5. On resume:
   - resume the originating gameplay scene;
   - **stop** the Paused scene (`this.scene.stop()` or equivalent), not merely hide it.
6. Verify 20 consecutive pause/resume cycles:
   - only one Paused scene instance active at a time;
   - no duplicated timers/listeners;
   - one input = one resume.

---

# 12. Align Info / Main Menu current visual treatment

## `assets/js/info.js` — entry lines ~27–180
## `assets/js/mainmenu.js` — entry lines ~35–210

Do not replace the now-correct font binaries.

Required:

- active headings use exact current Gold/Silver production family constants;
- body copy uses current Silver/white/cyan hierarchy;
- remove legacy blanket green/red tints from finished Founder-owned UI images unless an asset specification explicitly requires tinting;
- use scale/glow/opacity or supplied state imagery for hover/selection;
- remove hidden/dead green legacy title code from Main Menu if it serves no runtime purpose;
- preserve current accepted favicon unchanged.

---

# 13. Professional copy correction without changing story intent

## `assets/js/game.js` — `StoryContent` around entry lines ~83–105

Correct these exact defects:

- `Alien Hoards` -> `Alien Hordes`
- `whats that moving` -> `what's that moving`
- `we have been dooped` -> `we have been duped`
- `Your our only HOPE!` -> `You're our only HOPE!`

Proofread remaining user-facing copy for spelling/grammar only. Preserve the original story, tone, Gamma10 setting and meaning. Do not rewrite the narrative into new lore.

Update touch-control wording to describe actual actions accurately rather than ambiguous `Press Label` language.

---

# 14. Touch-input isolation

## Level1/Level2/Boss early `create()` touch blocks — approximately lines ~105–175 per scene

Current global `this.input.on("pointerdown", ...)` can fire a laser for any touch on the scene.

Required:

1. A touch on mute, nuke, pause, result, menu, replay, info or other UI must **not** also fire a player laser.
2. Gate firing to gameplay-state touches that are not consumed by an interactive UI control, or implement an explicit gameplay fire zone.
3. Once `levelWon` or `RIP` is true, gameplay fire/movement touch handlers must not create projectiles.
4. Verify each UI touch control causes only its intended action.

---

# 15. Preserve settled APP4 corrections

Do not regress:
- exact Founder Gold/Silver web font binaries;
- favicon `assets/images/owned/ui/gg_hud_life_icon_v002.png`;
- no nuke particle spray;
- comet no-spin direction alignment;
- corrected result values and supplied button assets;
- current owned audio estate;
- archived/superseded asset hygiene.

---

# 16. Required verification matrix

The handoff is not complete until all of these pass on final pushed HEAD:

## Gameplay
- 100/100 deterministic PlayerLaser hits against Level1 target path.
- 100/100 against Level2 target path.
- 100/100 against Boss cruiser target path.
- 100/100 EnemyLaser hits against player target path.
- Mothership direct-hit test decrements exactly once.
- no visible intersecting laser passes through without collision.
- no double scoring/double destruction callback.

## Scales at 1366x665
- Player class scale constant `0.040`.
- standard enemy `0.024`.
- scout `0.025`.
- cruiser `0.034`.
- player laser `0.021`.
- enemy laser `0.018`.
- mothership laser `0.023`.

## Population
- Level1 = 58 standard enemies.
- Level2 = 87 standard enemies.
- Boss regular cruisers = 72.

## Sprite fidelity
- player/scout/destroyer/mothership/cruiser contact sheet shows no frame bleed;
- cruiser has explicit atlas frames, not blanket 836px slicing;
- animated hulls do not resize/jump between frames.

## State/UI
- Level1 result: NEXT/REPLAY/MENU all work by touch.
- Level2 result: NEXT/REPLAY/MENU all work by touch.
- Game Over on every gameplay scene: all visible buttons work.
- Final Victory: NEXT/REPLAY/MENU all work.
- Titles: explicit controls work; no forced transition.
- Pause: 20 pause/resume cycles cleanly stop/start Paused scene.

## Scoring
- completion bonus added exactly once in Level1, Level2 and Boss;
- displayed score equals authoritative runtime score after bonus.

## Runtime
- runtime exceptions = 0;
- unexpected HTTP/network failures = 0;
- no particle emitter managers for nuke effect;
- Docker rebuilt from final pushed HEAD and healthy on port 8027.

---

# 17. Evidence required

Return screenshots plus machine-readable report for:
- Level1 normal gameplay with full formation;
- Level2 normal gameplay with full formation;
- Boss gameplay with mothership, cruiser formation and scout;
- Player/Enemy/Mothership laser bodies overlaid or debug-evidenced against visuals;
- deterministic collision test summary;
- complete explicit sprite-frame contact sheet including cruiser;
- nuke projectile and burst lifecycle;
- Level1 result;
- Level2 result;
- final Victory;
- Game Over;
- Pause;
- Info;
- Titles/Credits;
- production font family proof for active surfaces.

New evidence root:
`docs/internal_governance/evidence/GALACTIC_GUNNERS_DEVTEAM_HANDOFF_IN_004/`

Do not write APP4 evidence as proof for Handoff 004.

---

# 18. Closure

Return only when:
- all authorised work committed and pushed;
- `HEAD == origin/feature/GG-COM-001`;
- worktree clean;
- POST_BOX contains boundary controls only;
- Docker rebuilt from final HEAD;
- `http://localhost:8027/` healthy;
- stop command remains `docker compose down`;
- no merge performed;
- Founder acceptance explicitly remains `PENDING`;
- sealed return SHA-256 supplied.

Do not declare Founder acceptance from automated verification.
