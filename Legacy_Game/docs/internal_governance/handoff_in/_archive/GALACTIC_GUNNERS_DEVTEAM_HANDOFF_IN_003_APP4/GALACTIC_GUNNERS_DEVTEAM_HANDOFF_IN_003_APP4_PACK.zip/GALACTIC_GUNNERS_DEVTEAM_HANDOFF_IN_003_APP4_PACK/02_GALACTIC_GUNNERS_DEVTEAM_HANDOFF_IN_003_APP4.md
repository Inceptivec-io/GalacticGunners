# GALACTIC_GUNNERS_DEVTEAM_HANDOFF_IN_003_APP4

## 1. Classification

**Priority:** P1 — Founder-acceptance blocking production correction  
**Entry HEAD:** `3c9f566cf2a7043569bee3aad74eadf437c257c6`  
**Branch:** `feature/GG-COM-001`  
**Merge authority:** Founder only  
**Merge:** prohibited  
**Scope:** remaining acceptance defects only

APP3 REV1 returned automated PASS but failed Founder visual/functional acceptance. APP4 exists to close the remaining defects once, accurately and with visual evidence.

---

## 2. Settled items — do not disturb

Unless required by one of the corrections below, preserve the already-settled APP3 behaviour, including:

- favicon source `assets/images/owned/ui/gg_hud_life_icon_v002.png`;
- working Docker preview on port `8027`;
- owned APP1 audio estate;
- truthful victory SCORE/WAVE/BONUS overlay concept;
- current result panel artwork authority;
- current no-merge boundary.

Do not create another round of unrelated visual churn.

---

## 3. Exact production font authority — mandatory

### 3.1 Failure observed

The returned runtime is still not visually using the exact Founder-authoritative production font treatment expected by the supplied packs.

### 3.2 Source authority

For the **gold production family**, source directly from the supplied package location:

`GalacticGunners_Gold_Display_Font_v1.0_PRODUCTION/web/`

Specifically use the production web assets supplied there, including the exact `.woff2` / `.woff` and supplied CSS implementation reference as applicable.

For the **silver production family**, use the corresponding supplied production web directory from:

`GalacticGunners_Silver_Display_Font_v1.0_PRODUCTION/web/`

### 3.3 Implementation rule

Do not merely copy font files and bind them to arbitrary renamed aliases while rendering a different fallback/legacy family.

Required proof:

1. exact source file SHA-256 matches the supplied POST_BOX authority;
2. browser network evidence shows the intended `.woff2` asset actually loaded;
3. `document.fonts.check(...)` passes using the intended family;
4. computed/runtime Phaser text style proves the intended family is first and active;
5. screenshot evidence shows the expected gold/silver glyph form rather than legacy/fallback typography.

### 3.4 Usage

Use the supplied gold and silver production font families consistently on the intended game title/result/UI surfaces. Supporting HUD text may use the separately approved display family only where visually appropriate and explicitly intended.

**No substitute font is acceptable where Founder production gold/silver is specified.**

---

## 4. Sprite extraction — no blanket frame slicing

### 4.1 Failure observed

Player/scout/enemy sprite extraction still shows duplicate/incorrect content because sheets are being treated as uniform rectangles based on guessed/fixed `frameWidth`/`frameHeight` values rather than actual sprite content boundaries.

### 4.2 Required approach

Stop relying on blind `load.spritesheet(... frameWidth, frameHeight ...)` where the source sheet does not contain truly uniform, exactly aligned cells.

For affected Founder-supplied sheets:

- player ship;
- scout;
- enemy ship / destruction sequences;
- any other sheet showing frame bleed or duplicate neighbouring imagery;

implement one of the following correctly:

1. **explicit Phaser atlas / JSON frame map** defining exact x/y/width/height rectangles per frame; or
2. deterministic build-time frame extraction to individual transparent PNG frames, preserving the original source sheet unchanged as source authority.

### 4.3 Content-boundary rule

Frame definitions must be based on the actual separated sprite regions / transparent whitespace boundaries in the Founder source, not an arbitrary equal pixel division.

### 4.4 Validation

For every affected sheet return:

- source dimensions;
- frame count;
- explicit frame rectangles or extracted frame manifest;
- screenshot/contact-sheet proof of each runtime frame individually;
- proof that no frame contains pixels from its neighbour.

Do not alter the authoritative source images merely to make a bad slicing assumption appear correct.

---

## 5. Enemy formation — retain game population, resize/reflow instead of deleting

### 5.1 Failure observed

APP3 reduced the number of alien ships to relieve crowding. That is not the requested correction.

### 5.2 Required outcome

Restore/retain the intended gameplay population unless there is a separately evidenced gameplay reason to change it.

Solve crowding through:

- smaller but still legible sprite sizing;
- formation spacing;
- row/column layout;
- sensible margins from HUD/playfield edges;
- formation width/height calculation based on the current viewport;
- responsive scaling where required.

### 5.3 UX constraint

The formation must:

- preserve readable separation between individual ships;
- not overlap the HUD;
- not appear as one dense wall of art;
- retain the intended challenge and enemy count;
- remain workable on the smallest supported production viewport.

Return before/after formation metrics and screenshots.

---

## 6. Comets — directionally stable, no spinning

### 6.1 Failure observed

Current comet runtime applies angular velocity. Founder authority requires comets to point in their direction of travel, not rotate continuously.

### 6.2 Required correction

Remove comet spin / angular velocity.

Each comet must orient once, or continuously if trajectory changes, to its velocity vector so the head points in the direction of travel and the tail trails behind.

The orientation must account for the actual native orientation of the supplied comet art.

### 6.3 Verification

Verify representative trajectories from:

- left to right;
- right to left;
- upward/downward diagonal variants where generated.

No spinning is permitted.

---

## 7. Lasers — double current APP3 visible size again

APP3 improved the lasers but Founder review requires them **at least twice as large again visually**.

### Required correction

Relative to APP3 returned state:

- player laser visible size >= 2x current APP3 visible presentation;
- enemy laser visible size >= 2x current APP3 visible presentation;
- mothership laser scaled consistently and clearly distinguishable;
- preserve the previously required orientation:
  - player laser faces/travels upward;
  - enemy laser faces/travels downward.

Collision bodies remain based on the meaningful projectile core, not glow padding.

Validate visibility in live gameplay, not only isolated screenshots.

---

## 8. Nuclear projectile and nuclear explosion — separate assets and lifecycle

### 8.1 Failure observed

Founder review identifies:

- nuclear projectile imagery being reused/duplicated where the explosion should be;
- duplicated nuclear imagery during firing;
- an unwanted animated particle/spray trail/effect around the nuclear event;
- explosion presentation not using the correct supplied nuclear burst/explosion sequence.

### 8.2 Required asset separation

There must be a strict runtime distinction:

**Projectile:** supplied nuclear projectile sprite/animation.  
**Detonation:** supplied nuclear burst/explosion sprite/animation.

The projectile must never be rendered as the detonation effect.

### 8.3 Lifecycle

Expected lifecycle:

`fire -> one projectile -> projectile travels -> impact/detonation -> projectile removed -> nuclear burst/explosion plays once -> burst cleans up`

No duplicate projectile instance should appear during firing.

### 8.4 Remove particle spray

Remove the current generic emitter/particle spray/trailing effect from the nuclear projectile/event unless the supplied nuclear art itself contains the intended visual effect.

Do not start/follow the generic emitter from the Nuke entity.

Nuclear presentation must come from the supplied owned projectile and burst/explosion art, not an unrelated Phaser particle spray.

### 8.5 Verification

Return frame-by-frame or short sequential screenshot evidence showing:

1. single projectile in flight;
2. projectile removed at detonation;
3. correct nuke burst asset begins;
4. burst progresses;
5. burst ends/cleans up;
6. no duplicate projectile and no generic particle spray.

---

## 9. Buttons — functional everywhere they are visually presented

### 9.1 Failure observed

Founder review finds the corrected buttons functioning on the continue/result page but not consistently across all surfaces where equivalent visible buttons are presented.

### 9.2 Universal interaction rule

**Every visible button rendered as a button must be a real interactive control.**

This applies wherever relevant across:

- level-complete / continue screens;
- game-over screens;
- final victory screen;
- replay/try-again/menu surfaces;
- pause/resume/restart/menu surfaces where button art is shown;
- any other state presenting clickable/tappable visual controls.

### 9.3 Input parity

Each control must support the applicable:

- mouse pointer;
- touchscreen;
- keyboard;
- controller/gamepad.

Mouse/touch hit areas must map accurately to the visible control and must not rely on generic full-screen `pointerdown` behaviour.

### 9.4 State parity

Where off/on-click state assets exist, wire them consistently on every applicable screen.

### 9.5 Semantic correctness

MENU, REPLAY, TRY AGAIN, NEXT, RESUME and RESTART must each perform the correct state-specific action.

Return a screen/control matrix showing every visible button and all supported inputs with PASS evidence.

---

## 10. Do not reduce defects to automated HTTP checks

APP3 reported PASS while Founder immediately found visible defects. APP4 verification must include actual visual/semantic assertions.

Minimum semantic gates:

- exact Founder production font is visibly and programmatically active;
- sprite frame rectangles contain no neighbour bleed;
- intended enemy population preserved and formation fits viewport;
- comet angle matches velocity and angular velocity is zero;
- laser visible dimensions meet >=2x APP3 requirement;
- one nuke projectile only;
- nuke detonation uses burst asset, not projectile asset;
- no generic nuke particle emitter spray;
- every visually rendered button has a working independent input target;
- touch tests exercise every result/control surface, not only one continue page;
- runtime exceptions = 0;
- unexpected network/asset failures = 0.

---

## 11. Full bounded regression

After implementing the above, regress the complete APP1/APP2/APP3 production surface sufficiently to prove these changes did not regress settled behaviour.

At minimum:

- Main Menu;
- info/help;
- Level 1;
- Level 2;
- boss/final level;
- pause/resume;
- game over;
- level complete;
- final victory;
- touch controls;
- keyboard controls;
- gamepad controls;
- audio;
- score continuity;
- favicon settled source;
- responsive production viewport(s).

---

## 12. Evidence required for Founder acceptance

Return visual evidence, not just JSON reports, for:

1. exact gold font surface;
2. exact silver font surface;
3. player frames individually;
4. scout frames individually;
5. enemy frames individually where corrected;
6. full intended enemy formation;
7. left->right comet correctly oriented;
8. right->left comet correctly oriented;
9. enlarged player laser in live play;
10. enlarged enemy laser in live play;
11. nuke projectile in flight;
12. nuke burst/explosion sequence;
13. no nuke spray/duplicate projectile;
14. every result/control screen with interactive buttons;
15. touch interaction evidence for each applicable button surface.

---

## 13. Closure

Return only when:

- all authorised work committed and pushed;
- `HEAD == origin/feature/GG-COM-001`;
- worktree clean;
- Docker rebuilt from final pushed HEAD;
- Docker healthy at `http://localhost:8027/`;
- POST_BOX contains boundary controls only;
- no merge performed;
- Founder acceptance remains `PENDING` until Founder personally reviews runtime;
- sealed handoff-out SHA-256 supplied.

Do not claim final acceptance from automated verification.
