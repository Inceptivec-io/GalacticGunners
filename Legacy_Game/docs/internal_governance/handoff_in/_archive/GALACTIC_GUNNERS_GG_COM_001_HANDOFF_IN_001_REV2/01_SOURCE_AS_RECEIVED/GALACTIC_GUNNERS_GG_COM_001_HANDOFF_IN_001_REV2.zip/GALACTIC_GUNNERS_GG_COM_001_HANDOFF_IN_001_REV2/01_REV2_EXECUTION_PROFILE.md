# REV2 EXECUTION PROFILE — GALACTIC GUNNERS GG-COM-001 CLOSURE

You are performing **closure correction only**.

Your objective is not to create more product functionality.

Your objective is to leave a clean, governed, fully reconciled execution estate.

Hard rules:

```text
PERSISTENT BOUNDARY STAYS
TRANSIENT POST_BOX PAYLOAD GOES
EVIDENCE MOVES TO GOVERNED EVIDENCE/HANDOFF SURFACES
POST_BOX CLOSES EMPTY
LOCAL TMP CLOSES EMPTY
AGENTS.md IS TRACKED
ALL AUTHORISED WORK IS COMMITTED
ALL AUTHORISED WORK IS PUSHED
LOCAL FEATURE HEAD == REMOTE FEATURE HEAD
WORKTREE CLOSES CLEAN
```

Do not use POST_BOX as archive or Handoff-Out storage.

Do not remove evidence merely to make the POST_BOX empty.

First preserve/register it in its admitted governed location, then clear the transient intake payload.

Do not delete unknown material.

Do not use destructive Git commands to create apparent cleanliness.

Do not begin the next programme.

Founder Michael retains acceptance and merge authority.
