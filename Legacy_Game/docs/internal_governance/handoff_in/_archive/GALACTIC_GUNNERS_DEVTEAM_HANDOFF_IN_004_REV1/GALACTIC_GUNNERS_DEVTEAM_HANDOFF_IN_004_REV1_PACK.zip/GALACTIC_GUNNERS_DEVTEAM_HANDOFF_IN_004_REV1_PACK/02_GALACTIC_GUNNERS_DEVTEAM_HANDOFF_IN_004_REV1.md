# GALACTIC_GUNNERS_DEVTEAM_HANDOFF_IN_004_REV1

## Classification

P1 acceptance-blocking bounded correction sprint  
Branch-constrained  
No merge  
Founder review pending

---

## 1. Mission

Correct the remaining gameplay, UI, asset-state and screen-integration defects identified by CTO review and the latest Founder review.

This sprint must resolve the active defects in one coherent bounded pass. The team is not to guess intent. This handoff defines the required execution.

---

## 2. Boundary

### 2.1 Branch

`feature/GG-COM-001`

### 2.2 Entry HEAD

`be5bb36235c8c9ccd81917a3e33b0fbd808581b8`

### 2.3 Merge rule

No merge is authorised. Founder only.

### 2.4 Scope rule

Only execute the corrections explicitly required by this handoff and the already-open Handoff 004 surface. Do not introduce unrelated feature work.

---

## 3. Founder-authoritative intake for this REV1

Treat the latest POST_BOX additions as authority for this pass, including:

- Founder-marked continue / mission-cleared review screenshot;
- Founder-marked game-over review screenshot;
- `gg_boss_mothership_normal_v002_sheet`;
- `gg_boss_mothership_HIT_v002_sheet`;
- `gg_explosion_large_v002_sheet_horizontal`;
- vertically stacked comet sheet;
- all previously admitted Gold/Silver production web fonts;
- all previously admitted governed owned gameplay/runtime assets unless specifically superseded by the latest Founder intake.

Do not overwrite Founder source assets. If a runtime derivative is necessary, preserve the source unchanged and register the derivative correctly.

---

## 4. Continue / mission-cleared screen correction

### 4.1 Dynamic value placement

Current implementation is incorrect.

Required:

1. The values for score, wave and bonus must appear in the dedicated lower panel value cells.
2. They must sit under the headings already built into the image artwork.
3. Do **not** render redundant text labels such as `SCORE`, `WAVE`, `BONUS` as separate dynamic headings above the panel values.
4. Do **not** place the values in the central decorative area of the panel.
5. Maintain correct reading order:
   - left lower slot = score value;
   - centre lower slot = wave value;
   - right lower slot = bonus value.

### 4.2 Result controls

1. `NEXT`, `REPLAY`, and `MENU` must all work.
2. Their hit areas must align with the visual button surfaces.
3. Mouse, touch, keyboard and controller paths must all work.
4. No invisible overlay or misplaced hit zone is acceptable.

---

## 5. Game-over screen correction

### 5.1 Button alignment

The current clickable controls do not sit over the visual button counterparts.

Required:

1. Button hit areas must align to the actual visible printed controls in the image.
2. Where reusable governed button logic/assets from other result screens can be re-used cleanly, do so.
3. Do not duplicate controls or stack an extra clickable control above/below an unrelated decorative copy.
4. If a missing required state demands one additional bespoke runtime button asset, introduce it cleanly and register it.
5. Remove the current visually duplicated / semantically duplicated button problem.

### 5.2 Functional paths

All visible game-over controls must work on:

- mouse;
- touchscreen;
- keyboard equivalents;
- controller equivalents.

---

## 6. Enemy orientation, sizing and formation

### 6.1 Orientation

Alien ships are upside down.

Required:

- invert the gameplay alien ships **180 degrees** so they face the correct gameplay direction.

### 6.2 Level 1 scale

Required:

- make Level 1 alien ships approximately **20% larger** than the current returned state.

### 6.3 Row fit rule

Required:

- the full row must remain inside the playfield width;
- no ship may cross the left or right page boundary;
- do not solve this by deleting ships;
- solve it by correct sprite scale, spacing, formation width and playfield placement.

### 6.4 Population preservation

Retain the governed population targets already set in Handoff 004. Do not reduce counts.

---

## 7. Boss mothership state mapping

The boss currently must use different source imagery according to state.

### Required state mapping

1. **Normal flying / shooting:** use `gg_boss_mothership_normal_v002_sheet`.
2. **Hit / damaged state:** use `gg_boss_mothership_HIT_v002_sheet`.
3. **Death / final destruction:** use `gg_explosion_large_v002_sheet_horizontal`.

### Rules

- Do not use the same boss image for every state.
- Do not fake a hit state with only tinting if the Founder has supplied a dedicated hit-state source.
- Ensure state transitions are deterministic and visible during actual play.

---

## 8. Player ship animation restoration

The player ship currently uses only one image state and does not use the supplied four-frame authority correctly.

### Required frame semantics

- Frame 1: idle / normal.
- Frame 2: step-up thrust.
- Frame 3: full throttle.
- Frame 4: step-down return.

### Required behaviour

1. When stationary, the ship must use frame 1.
2. When movement begins, animate through the thrust-up progression.
3. While actively moving, use the stronger-thrust state appropriately.
4. When movement stops, step back down and return to idle.
5. Animation must be smooth and state-driven, not permanently looping regardless of input.
6. Hull anchoring must remain stable with no visual pumping/jumping.

---

## 9. HUD nuke indicator correction

Replace the current text-led nuke indicator approach.

Required:

1. Use the scaled owned image `gg_hud_nuke_icon_v002` as the primary HUD nuke icon.
2. Pair it with the live numeric remaining count.
3. Ensure the icon and count are visually aligned with the HUD system.
4. The runtime must still clearly expose the remaining nuke quantity.

---

## 10. Collision and gameplay reliability

This remains a stop-the-line gameplay defect.

### Required

1. Repair laser collision reliability.
2. Repair nuke collision reliability.
3. Ensure both lasers and nukes consistently kill/trigger correctly on intersecting targets.
4. Ensure collision bodies are mapped to meaningful sprite extents.
5. Ensure the repaired physics/velocity path from Handoff 004 is applied everywhere relevant.

### Acceptance rule

If a visible laser or visible nuke clearly intersects a valid target in a deterministic collision test, the intended game-state effect must occur.

---

## 11. Nuke sprite slicing

The nuke sheet has 6 images and is not currently sliced correctly.

### Required

1. Slice the 6-frame nuke sheet correctly.
2. Remove the current malformed/strange visual effect caused by incorrect slicing.
3. Ensure the in-flight projectile sequence uses the intended frames only.
4. Keep projectile and burst/explosion roles separated.
5. Do not reuse projectile frames as burst frames.

---

## 12. Comet variant correction

A new vertically stacked comet source is now available and must be used.

### Required

1. Use the vertically stacked comet sheet as runtime authority for the comet variants in this pass.
2. Randomly select variants across the sheet.
3. Ensure comets point in the direction of travel.
4. For downward travel, the comet nose must point downward and the tail must trail upward.
5. Do not allow the same comet variant to dominate continuously unless random selection genuinely produces it occasionally.
6. Preserve the no-spin rule.

---

## 13. Tooling and verification

In addition to the already-issued QA-toolchain instruction:

1. The new verifier must explicitly test the REV1 continue-screen numeric placement under the built-in headings.
2. It must verify every continue-screen button is clickable and aligned.
3. It must verify game-over buttons align to the visible artwork and work.
4. It must verify alien orientation is corrected by 180 degrees.
5. It must verify Level 1 alien scale is materially larger while the row remains inside bounds.
6. It must verify boss state imagery transitions.
7. It must verify player-ship idle/move/return animation states.
8. It must verify the HUD nuke icon is the governed image rather than the word-only presentation.
9. It must verify nuke frame count and slicing correctness.
10. It must verify comet variant selection and direction-of-travel orientation.

Evidence must include screenshots and machine-readable reports for all of the above.

---

## 14. Closure requirements

Return only when:

- all authorised work is committed and pushed;
- `HEAD == origin/feature/GG-COM-001`;
- worktree clean;
- POST_BOX contains only `BOUNDARY.md` and `README.md`;
- Docker rebuilt from final pushed HEAD;
- preview healthy at `http://localhost:8027/`;
- stop command remains `docker compose down`;
- no merge performed;
- Founder acceptance remains `PENDING`.

---

## 15. Return format

Return one governed handoff-out package with:

- final pushed SHA;
- local/remote proof;
- concise implemented-change summary;
- exact verification summary;
- evidence locations;
- register/currentness/archive update summary;
- closure summary;
- sealed return SHA-256.

