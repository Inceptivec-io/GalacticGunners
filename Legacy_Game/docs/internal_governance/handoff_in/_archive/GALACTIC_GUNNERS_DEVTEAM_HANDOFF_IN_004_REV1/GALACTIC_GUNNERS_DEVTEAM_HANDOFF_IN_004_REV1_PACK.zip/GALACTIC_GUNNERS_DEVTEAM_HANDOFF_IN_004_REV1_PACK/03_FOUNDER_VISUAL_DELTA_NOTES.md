# FOUNDER VISUAL DELTA NOTES

These notes capture the latest explicit Founder review findings and are to be treated as acceptance authority for this sprint.

## Continue / mission-cleared screen

- Dynamic values must sit beneath the panel headings already present in the artwork.
- Do not prepend redundant text labels such as `SCORE`, `WAVE`, `BONUS` above/over the image panel value slots.
- The numeric values must be placed in the lower dedicated panel value cells under the built-in headings.
- The visible `NEXT`, `REPLAY`, `MENU` buttons must all work.

## Game-over screen

- Button hit areas do not currently align with the printed button counterparts in the artwork.
- Re-use compatible button assets/behaviour patterns from other result screens where appropriate.
- If an additional bespoke button asset is genuinely needed, create/use it cleanly; otherwise reuse existing governed button assets.

## Enemy orientation and sizing

- Alien ships are upside down and must be inverted 180 degrees so they face the correct gameplay direction.
- On Level 1 they must be approximately 20% larger than the current returned state.
- The full row must still remain inside the playfield width and must not cross the page boundary.

## Boss state imagery

- Normal flying/shooting state must use `gg_boss_mothership_normal_v002_sheet`.
- Hit/damaged state must use `gg_boss_mothership_HIT_v002_sheet`.
- Death of mothership must use `gg_explosion_large_v002_sheet_horizontal`.

## Player ship animation

- The 4-frame player ship sheet is not being used correctly.
- Frame semantics are:
  1. idle / normal;
  2. step-up thrust;
  3. full throttle;
  4. step-down return.
- When not moving, the player must use frame 1.
- When moving, it must step through the thrust frames and visually return to normal when movement stops.

## HUD nuke indicator

- The word `Nuke` should not be the primary indicator for remaining nukes.
- Use the scaled image asset `gg_hud_nuke_icon_v002` as the HUD icon and pair it with the live count.

## Collision reliability

- Lasers and nukes still do not always collide/kill correctly.
- Collision remains incorrect for both laser and nuke paths and must be repaired as gameplay-critical authority.

## Nuke sprite slicing

- The nuke sheet contains 6 images and is not currently being sliced/used correctly.
- The strange current effect is not accepted.

## Comets

- The newly available vertically stacked comet variants must be used.
- Variants should be selected randomly across the sprite sheet.
- Comets must point in the direction of travel; downward travel means nose-down / tail-up orientation.
- You should not see the same comet all the time.
