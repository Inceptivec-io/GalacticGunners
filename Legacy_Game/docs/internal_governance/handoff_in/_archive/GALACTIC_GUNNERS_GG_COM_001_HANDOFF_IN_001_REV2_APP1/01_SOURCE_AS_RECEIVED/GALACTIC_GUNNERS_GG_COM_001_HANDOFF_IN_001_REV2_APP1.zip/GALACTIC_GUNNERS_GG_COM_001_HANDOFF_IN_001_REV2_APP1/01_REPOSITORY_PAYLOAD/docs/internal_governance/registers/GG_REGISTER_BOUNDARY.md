# GALACTIC GUNNERS — BOUNDARY REGISTER

| Boundary ID | Class | Path | Parent | Purpose | Direction | Operator | Mutation Mode | Status | Last Review |
|---|---|---|---|---|---|---|---|---|---|
| GG-EXT-001 | PROJECT EXTERNAL | `_EXTERNAL_GalacticGunners` | Galactic Gunners | Persistent external exchange boundary | controlled | Founder/authorised Worker | boundary-only | CURRENT | |
| GG-WORK-00000001 | WORK POST_BOX | `_EXTERNAL_GalacticGunners/_GalacticGunners_MAIN_POST_BOX/_WORK_00000001_POST_BOX` | GG-EXT-001 | Controlled exchange address | explicit per BOUNDARY.md | authorised Worker | payload transient | CURRENT | |
