param(
    [string]$RepoRoot = "C:\Users\Michael\dev\GalacticGunners",
    [string]$PackPayload = ".\01_REPOSITORY_PAYLOAD"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $RepoRoot)) { throw "Repo root not found: $RepoRoot" }
if (-not (Test-Path $PackPayload)) { throw "Pack payload not found: $PackPayload" }

$target = Join-Path $RepoRoot "docs\internal_governance"
$source = Join-Path $PackPayload "docs\internal_governance"

New-Item -ItemType Directory -Force -Path $target | Out-Null

# Copy supplied canonical substrate. Existing files are not silently deleted.
Copy-Item -Path (Join-Path $source "*") -Destination $target -Recurse -Force

Write-Host "Governance payload applied to $target"
Write-Host "Now reconcile any existing GG-COM-001 register data into canonical supplied registers."
Write-Host "Do not delete unknown/unique material."
