# GALACTIC GUNNERS — WORKER / EXECUTOR REGISTER

| Executor ID | Type | Assignment | Active Handoff | Repository | Branch | Mutation Scope | Status | Evidence |
|---|---|---|---|---|---|---|---|---|
