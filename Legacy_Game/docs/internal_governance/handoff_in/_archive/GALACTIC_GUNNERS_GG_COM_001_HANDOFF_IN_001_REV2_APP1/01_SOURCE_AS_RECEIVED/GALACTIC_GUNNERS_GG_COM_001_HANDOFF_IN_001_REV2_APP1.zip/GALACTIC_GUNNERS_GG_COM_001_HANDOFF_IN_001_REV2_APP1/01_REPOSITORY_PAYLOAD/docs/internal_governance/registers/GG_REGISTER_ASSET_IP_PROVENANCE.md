# GALACTIC GUNNERS — ASSET / IP PROVENANCE REGISTER

| Asset ID | Path | Type | Creator/Source | Rights Basis | Classification | SHA256 | Supersedes | Status | Evidence |
|---|---|---|---|---|---|---|---|---|---|
