# GALACTIC_GUNNERS_GG_COM_001_HANDOFF_IN_001_REV2_APP1

## Immediate superseding amendment to active REV2

This APP1 supersedes any REV2 wording that asks Development to derive, adapt, infer or design the governance estate.

Development must implement the supplied `01_REPOSITORY_PAYLOAD` exactly, reconciling only where an existing file with the same canonical concern already contains authoritative GG-COM-001 data.

## Required action

1. Copy the supplied `docs/internal_governance/` tree into the repository root at:
   `C:\Users\Michael\dev\GalacticGunners\docs\internal_governance\`

2. Do NOT invent alternative folder names.

3. If GG-COM-001 has already created registers elsewhere:
   - preserve their data;
   - merge their entries into the supplied canonical project registers;
   - do not create duplicate living registers;
   - record the old path/disposition in evidence.

4. Preserve root `AGENTS.md` unchanged and track it.

5. Move/preserve consumed HANDOFF_IN evidence from POST_BOX into:
   `docs/internal_governance/handoff_in/_archive/<HANDOFF_ID>/`

6. Move/preserve sealed HANDOFF_OUT evidence into:
   `docs/internal_governance/handoff_out/_archive/<HANDOFF_OUT_ID>/`

7. Store supporting durable evidence under:
   `docs/internal_governance/evidence/<HANDOFF_ID>/`

8. POST_BOX must close with persistent `BOUNDARY.md` / `README.md` controls only and zero active payload.

9. Update:
   - all supplied registers;
   - `currentness/CURRENT_STATE.md`;
   - governance debt register.

10. Track, commit and push all authorised work to `feature/GG-COM-001`.

11. Verify local HEAD equals `origin/feature/GG-COM-001`.

12. Worktree must be clean.

13. Return only after full Safe Exit.

## Explicit prohibition

Do not start IP Freedom asset integration.
Do not add leaderboard/platform work.
Do not merge main.
Do not mutate CLOM.
Do not rewrite earlier evidence to hide defects.

## Required closure

PASS only if:

```text
INTERNAL_GOVERNANCE_COMPLETE=true
PROJECT_STANDARDS_PRESENT=true
PROJECT_PROCEDURES_PRESENT=true
PROJECT_REGISTERS_CURRENT=true
HANDOFF_IN_ARCHIVED=true
HANDOFF_OUT_ARCHIVED=true
EVIDENCE_DURABLE=true
POST_BOX_PAYLOAD=0
TMP_PAYLOAD=0_OR_NA
AGENTS_TRACKED=true
WORKTREE_CLEAN=true
AUTHORISED_WORK_COMMITTED=true
AUTHORISED_WORK_PUSHED=true
LOCAL_HEAD_EQUALS_REMOTE_HEAD=true
UNTRACKED_OPERATIONAL_MATERIAL=0
FOUNDER_ACCEPTANCE=PENDING
```
