# GALACTIC GUNNERS — CURRENTNESS / GOVERNANCE DEBT REGISTER

| ID | Concern | State | Owner | Blocking Level | Next Action | Successor/Programme | Evidence |
|---|---|---|---|---|---|---|---|
| GG-DEBT-001 | legacy non-core media/fonts/nuke sound/utilities | KNOWN REPLACEMENT REQUIRED | Founder / Inceptivec Gamification | blocks commercial release, not GG-COM-001 governance closure | execute approved IP Freedom pack after GG-COM-001 closure | `IP_FREEDOM_LICENSE_PROTECTION_ASSET_CREATION` | GG-COM-001 provenance |
| GG-DEBT-002 | Aurora signed commercial terms | DRAFT FRAMEWORK / UNSIGNED | Founder | blocks contractual finality | execute signed contributor/royalty agreement | commercial/legal follow-up | GG-COM-001 record |
